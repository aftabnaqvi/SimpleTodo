package org.codepath.team10.charitychallenger.models;

import com.parse.ParseUser;

/**
 * Adds additional methods on top of ParseUser.
 * 
 */
public class User extends ParseUser{

}
