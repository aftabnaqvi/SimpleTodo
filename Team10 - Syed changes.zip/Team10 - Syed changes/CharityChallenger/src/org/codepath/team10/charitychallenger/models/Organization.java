package org.codepath.team10.charitychallenger.models;

public class Organization {

}
