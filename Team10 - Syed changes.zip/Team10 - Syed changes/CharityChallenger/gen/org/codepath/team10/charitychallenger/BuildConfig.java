/** Automatically generated file. DO NOT MODIFY */
package org.codepath.team10.charitychallenger;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}